// MightexAppDlg.cpp : implementation file
//
#include "stdafx.h"
#include "MightexApp.h"
#include "MightexAppDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMightexAppDlg dialog
extern CMightexAppApp theApp;

CMightexAppDlg::CMightexAppDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMightexAppDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMightexAppDlg)
	m_FileName_Edit = _T("");
	m_SnapshotNum_Edit = _T("");
	m_Width_Edit = _T("");
	m_Height_Edit = _T("");
	m_Resolution_COMBO = -1;
	m_Resolution_RADIO = -1;
	m_Exposure_COMBO = -1;
	m_JPEGFile_CHK = FALSE;
	m_Append_DateTime_CHK = FALSE;
	m_FilePath_Edit = _T("");
	m_Compressor_CHK = FALSE;
	m_Compressor_COMBO = -1;
	m_FrameRate_Edit = _T("");
	m_Decimation_CHK = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMightexAppDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMightexAppDlg)
	DDX_Control(pDX, IDC_Compressor_CHK, m_Compressor_CHK_Ctrl);
	DDX_Control(pDX, IDC_SetFrameRateBtn, m_SetFrameRateBtn);
	DDX_Control(pDX, IDC_Exposure_COMBO, m_Exposure_COMBO_Ctrl);
	DDX_Control(pDX, IDC_Blue_SLIDER, m_Blue_SLIDER_Ctrl);
	DDX_Control(pDX, IDC_Red_SLIDER, m_Red_SLIDER_Ctrl);
	DDX_Control(pDX, IDC_Resolution_COMBO, m_Resolution_COMBO_Ctrl);
	DDX_Control(pDX, IDC_SetResolutionBtn, m_SetResolutionBtn);
	DDX_Control(pDX, IDC_Compressor_COMBO, m_Compressor_COMBO_Ctrl);
	DDX_Control(pDX, IDC_YStart_SLIDER, m_YStart_SLIDER_Ctrl);
	DDX_Control(pDX, IDC_XStart_SLIDER, m_XStart_SLIDER_Ctrl);
	DDX_Control(pDX, IDC_Device_COMBO, m_Device_COMBO_Ctrl);
	DDX_Control(pDX, IDC_Green_SLIDER, m_Green_SLIDER_Ctrl);
	DDX_Control(pDX, IDC_Exposure_SLIDER, m_Exposure_SLIDER_Ctrl);
	DDX_Control(pDX, IDC_ConnectBtn2, m_ConnectBtn2);
	DDX_Control(pDX, IDC_ConnectBtn, m_ConnectBtn);
	DDX_Text(pDX, IDC_FileName_Edit, m_FileName_Edit);
	DDX_Text(pDX, IDC_SnapshotNum_Edit, m_SnapshotNum_Edit);
	DDX_Text(pDX, IDC_Width_Edit, m_Width_Edit);
	DDX_Text(pDX, IDC_Height_Edit, m_Height_Edit);
	DDX_CBIndex(pDX, IDC_Resolution_COMBO, m_Resolution_COMBO);
	DDX_Radio(pDX, IDC_Resolution_RADIO1, m_Resolution_RADIO);
	DDX_CBIndex(pDX, IDC_Exposure_COMBO, m_Exposure_COMBO);
	DDX_Check(pDX, IDC_JPEGFile_CHK, m_JPEGFile_CHK);
	DDX_Check(pDX, IDC_Append_DateTime_CHK, m_Append_DateTime_CHK);
	DDX_Text(pDX, IDC_FilePath_Edit, m_FilePath_Edit);
	DDX_Check(pDX, IDC_Compressor_CHK, m_Compressor_CHK);
	DDX_CBIndex(pDX, IDC_Compressor_COMBO, m_Compressor_COMBO);
	DDX_Text(pDX, IDC_FrameRate_Edit, m_FrameRate_Edit);
	DDX_Check(pDX, IDC_Decimation_CHK, m_Decimation_CHK);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMightexAppDlg, CDialog)
	//{{AFX_MSG_MAP(CMightexAppDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ConnectBtn, OnConnectBtn)
	ON_BN_CLICKED(IDC_SnapshotBtn, OnSnapshotBtn)
	ON_BN_CLICKED(IDC_ConnectBtn2, OnConnectBtn2)
	ON_BN_CLICKED(IDC_SetResolutionBtn, OnSetResolutionBtn)
	ON_WM_HSCROLL()
	ON_CBN_SELCHANGE(IDC_Exposure_COMBO, OnSelchangeExposureCOMBO)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_Compressor_CHK, OnCompressorCHK)
	ON_BN_CLICKED(IDC_SetFrameRateBtn, OnSetFrameRateBtn)
	ON_BN_CLICKED(IDC_WorkMode_RADIO1, OnWorkModeRADIO)
	ON_BN_CLICKED(IDC_WorkMode_RADIO2, OnWorkModeRADIO2)
	ON_BN_CLICKED(IDC_PropertyPageBtn, OnPropertyPageBtn)
	ON_BN_CLICKED(IDC_SelectFilePathBtn, OnSelectFilePathBtn)
	ON_WM_TIMER()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMightexAppDlg message handlers

BOOL CMightexAppDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	Init();//INIT Variables and Controls

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model, 
//  this is automatically done for you by the framework.

void CMightexAppDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMightexAppDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


/////////////////////////////////////////////////////////////////////////////

void CMightexAppDlg::Init()
{//INIT Variables and Controls
	//////////////////////////////////////////////////////////////////////////
	//INIT Variables

	HRESULT hr;
	
	mightex_VideoShow = new CMightex_VideoShow;
	hr = mightex_VideoShow->Init();
    if (FAILED(hr))
    {
		EndDialog(IDCANCEL);
		MessageBox("No Camera!", "Alert!", MB_OK);
        return;
    }
	ghApp = NULL;

	m_FileName_Edit = "cap";
	m_SnapshotNum_Edit = "1";
	m_Resolution_RADIO = 0;
	m_Exposure_COMBO = 2;
	m_FrameRate_Edit = "30.00";
	
	UpdateData(FALSE);
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	//INIT Controls

	CCameraControl cameraCtrl;
	mightex_VideoShow->GetCameraControl(cameraCtrl);

	//init Device_COMBO and DeviceName_STATIC
	m_Device_COMBO_Ctrl.AddString(CString(cameraCtrl.ModuleNo)+":"+CString(cameraCtrl.SerialNo));
	m_Device_COMBO_Ctrl.SetCurSel(0);
	SetDlgItemText(IDC_DeviceName_STATIC, "Device: "+CString(cameraCtrl.ModuleNo)+":"+CString(cameraCtrl.SerialNo));
	
	//init WorkMode_RADIO
	CheckRadioButton(IDC_WorkMode_RADIO1, IDC_WorkMode_RADIO2, IDC_WorkMode_RADIO1);
	
	//init Resolution_COMBO
	char tempstr[32];
	for(int i = 0; i <= cameraCtrl.MAX_RESOLUTION; i++)
	{
		sprintf(tempstr, "%d*%d", s_vidFrameSize[i].width, s_vidFrameSize[i].height);
		m_Resolution_COMBO_Ctrl.AddString(tempstr);
	}
	m_Resolution_COMBO_Ctrl.SetCurSel(MAX_RESOLUTIONS_V032);

	//init Resolution_Edit
	int MAX_width = s_vidFrameSize[cameraCtrl.MAX_RESOLUTION].width;
	int MAX_height = s_vidFrameSize[cameraCtrl.MAX_RESOLUTION].height;
	_itoa(MAX_width, tempstr, 10);
	SetDlgItemText(IDC_Width_Edit, CString(tempstr));
	_itoa(MAX_height, tempstr, 10);
	SetDlgItemText(IDC_Height_Edit, CString(tempstr));
	
	//init Exposure_SLIDER
	m_Exposure_SLIDER_Ctrl.SetRange(1, 100);
	m_Exposure_SLIDER_Ctrl.SetPos(cameraCtrl.exposureTime / 20); //20 = 1000 / 50
	sprintf(tempstr, "Exposure Time: ( %dms )", cameraCtrl.exposureTime / 20); //20 = 1000 / 50
	SetDlgItemText(IDC_ExposureTime_STATIC, CString( tempstr ) );
	
	//init Green\Red\Blue_SLIDER
	m_Green_SLIDER_Ctrl.SetRange(1, 64);
	m_Green_SLIDER_Ctrl.SetPos(cameraCtrl.greenGain);
	m_Red_SLIDER_Ctrl.SetRange(1, 64);
	m_Red_SLIDER_Ctrl.SetPos(cameraCtrl.redGain);
	m_Blue_SLIDER_Ctrl.SetRange(1, 64);
	m_Blue_SLIDER_Ctrl.SetPos(cameraCtrl.blueGain);
	if (cameraCtrl.DeviceType == MT9T001) 
	{
		m_Red_SLIDER_Ctrl.ShowWindow(TRUE);
		m_Blue_SLIDER_Ctrl.ShowWindow(TRUE);
	}
	else
	{
		SetDlgItemText(IDC_Red_STATIC, CString("") );
		SetDlgItemText(IDC_Green_STATIC, CString("Global") );
		SetDlgItemText(IDC_Blue_STATIC, CString("") );		
	}
	
	//init Compressor_COMBO
	CStringList m_CompressorList;
	hr = mightex_VideoShow->AddCompressorsToList(m_CompressorList);
	if(FAILED(hr))
		m_Compressor_CHK_Ctrl.EnableWindow(FALSE);
	else
	{
		for(POSITION pos = m_CompressorList.GetHeadPosition(); pos != NULL;)
		{
			m_Compressor_COMBO_Ctrl.AddString(m_CompressorList.GetNext(pos));
		}
		m_CompressorList.RemoveAll();
		m_Compressor_COMBO_Ctrl.SetCurSel(0);
	}
	
	OnSetResolutionBtn();

	SetTimer(1, 100, NULL);

	//SetGPIO
//	if(mightex_VideoShow->SetGPIOConifg(15) == S_OK)
//	{
//		char stateMsg[16];
//		sprintf(stateMsg, "GPIOCfg=15");
//		SetDlgItemText(IDC_State_STATIC,stateMsg);		
//	}
//	unsigned char InputByte;
//	if(mightex_VideoShow->SetGPIOInOut(0, &InputByte) == S_OK)
//	{
//		char stateMsg[16];
//		sprintf(stateMsg, "GPIO:out0in%d", InputByte&0x0F);
//		SetDlgItemText(IDC_Snapshot_STATIC,stateMsg);		
//	}
	
	//////////////////////////////////////////////////////////////////////////	
}

CMightexAppDlg::~CMightexAppDlg()
{
	if(mightex_VideoShow) delete mightex_VideoShow;
	mightex_VideoShow = NULL;
	CoUninitialize();
}

void CMightexAppDlg::OnConnectBtn() 
{//Capturing
	if(!(mightex_VideoShow->GetCaptureState()))
	{
		SetDlgItemText(IDC_ConnectBtn, "StopCapture");
		m_SetResolutionBtn.EnableWindow(FALSE);
		m_SetFrameRateBtn.EnableWindow(FALSE);
		m_Exposure_SLIDER_Ctrl.EnableWindow(FALSE);
		m_Exposure_COMBO_Ctrl.EnableWindow(FALSE);

		UpdateData();
		WCHAR TargetFile[256];
		// Convert target filename
		MultiByteToWideChar(CP_ACP, 0, (const char *)(m_FilePath_Edit+m_FileName_Edit+".avi"), -1, 
			TargetFile, NUMELMS(TargetFile));
		int compressorNum = -1;
		if (m_Compressor_CHK)
			compressorNum = m_Compressor_COMBO;
		mightex_VideoShow->Capture(TargetFile, compressorNum);

		SetDlgItemText(IDC_State_STATIC, "Capturing...");	
	}
	else
	{		
		mightex_VideoShow->StopCapture();
		
		SetDlgItemText(IDC_ConnectBtn, "Capture");
		SetDlgItemText(IDC_State_STATIC, "");	
		m_SetResolutionBtn.EnableWindow(TRUE);
		m_SetFrameRateBtn.EnableWindow(TRUE);
		m_Exposure_SLIDER_Ctrl.EnableWindow(TRUE);
		m_Exposure_COMBO_Ctrl.EnableWindow(TRUE);
	}
}

void CMightexAppDlg::OnConnectBtn2() 
{//Previewing
	CCameraControl cameraCtrl;
	mightex_VideoShow->GetCameraControl(cameraCtrl);

	if(!(mightex_VideoShow->GetPreviewState()))
	{
		if (!ghApp) {
			// Create the video window.  The WS_CLIPCHILDREN style is required.
			ghApp = CreateWindow(TEXT("Demo\0"), TEXT("MightexApp Demo\0"), 
				WS_OVERLAPPEDWINDOW | WS_CAPTION | WS_CLIPCHILDREN, 
				CW_USEDEFAULT, CW_USEDEFAULT, 
				cameraCtrl.width, cameraCtrl.height, 
				m_hWnd, 0, theApp.m_hInstance, 0);
		}
		mightex_VideoShow->Preview(ghApp);
		SetDlgItemText(IDC_ConnectBtn2, "StopPreview");
	}
	else
	{
		mightex_VideoShow->StopPreview();
		SetDlgItemText(IDC_ConnectBtn2, "Preview");
	}
}

void CMightexAppDlg::OnSnapshotBtn() 
{//Snapshot
	UpdateData();
	int snapshotNum = atoi((const char *)m_SnapshotNum_Edit);
	mightex_VideoShow->Snapshot((char *)(const char *)(m_FilePath_Edit+m_FileName_Edit), 
		TRUE, m_JPEGFile_CHK, m_Append_DateTime_CHK, FALSE, snapshotNum, 0);

	char stateMsg[16];
	sprintf(stateMsg, "Snapshot %dp", snapshotNum);
	SetDlgItemText(IDC_Snapshot_STATIC,stateMsg);
}

void CMightexAppDlg::OnSetResolutionBtn() 
{//SetResolution
	CCameraControl cameraCtrl;
	mightex_VideoShow->GetCameraControl(cameraCtrl);
	int MAX_width = s_vidFrameSize[cameraCtrl.MAX_RESOLUTION].width;
	int MAX_height = s_vidFrameSize[cameraCtrl.MAX_RESOLUTION].height;
	
	UpdateData();
	int width = MAX_width, height = MAX_height;
	if (m_Resolution_RADIO == 0) 
	{
		width = s_vidFrameSize[m_Resolution_COMBO].width;
		height = s_vidFrameSize[m_Resolution_COMBO].height;
	}
	else
	{
		width = atoi((const char *)m_Width_Edit);
		height = atoi((const char *)m_Height_Edit);
	}
	
	mightex_VideoShow->SetResolution(width, height, m_Decimation_CHK);
	
	char stateMsg[16];
	sprintf(stateMsg, "%dx%d", width, height);
	SetDlgItemText(IDC_Resolution_STATIC, stateMsg);

	if(MAX_width-width>0)
	{
		m_XStart_SLIDER_Ctrl.SetRange(0, MAX_width-width);
		m_XStart_SLIDER_Ctrl.EnableWindow(TRUE);
	}
	else
	{
		m_XStart_SLIDER_Ctrl.ClearTics();
		m_XStart_SLIDER_Ctrl.EnableWindow(FALSE);
	}
	m_XStart_SLIDER_Ctrl.SetPos(0);
	
	if(MAX_height-height>0)
	{
		m_YStart_SLIDER_Ctrl.SetRange(0, MAX_height-height);		
		m_YStart_SLIDER_Ctrl.EnableWindow(TRUE);
	}
	else
	{
		m_YStart_SLIDER_Ctrl.ClearTics();
		m_YStart_SLIDER_Ctrl.EnableWindow(FALSE);
	}
	m_YStart_SLIDER_Ctrl.SetPos(0);
}

void CMightexAppDlg::OnSelchangeExposureCOMBO() 
{//Changing Exposure Time Range
	UpdateData();
	int frameTimePos = m_Exposure_SLIDER_Ctrl.GetPos();
	float f_frameTime = frameTimePos * MAX_EXPOSURETIME[m_Exposure_COMBO] / 100.000;
	int i_frameTime = frameTimePos * MAX_EXPOSURETIME[m_Exposure_COMBO] * 10 / 50;//50 Microsecond UNIT
	mightex_VideoShow->SetExposureTime(i_frameTime);
	
	char frameTimeStr[32];
	sprintf(frameTimeStr, "Exposure Time: ( %gms )", f_frameTime);
	SetDlgItemText(IDC_ExposureTime_STATIC, CString( frameTimeStr ) );
}

void CMightexAppDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{//Changing Exposure Time
	if(&m_Exposure_SLIDER_Ctrl == ((CSliderCtrl *)pScrollBar))
	{
		int frameTimePos = m_Exposure_SLIDER_Ctrl.GetPos();
		float f_frameTime = frameTimePos * MAX_EXPOSURETIME[m_Exposure_COMBO] / 100.000;
		//int i_frameTime = (int(f_frameTime) == 0 ? 1 : int(f_frameTime));
		int i_frameTime = frameTimePos * MAX_EXPOSURETIME[m_Exposure_COMBO] * 10 / 50;//50 Microsecond UNIT
		mightex_VideoShow->SetExposureTime(i_frameTime);

		char frameTimeStr[32];
		sprintf(frameTimeStr, "Exposure Time: ( %gms )", f_frameTime);
		SetDlgItemText(IDC_ExposureTime_STATIC, CString( frameTimeStr ) );
	}
	
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CMightexAppDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{//Changing Red\Green\Blue Color or XYStart
	if(&m_Red_SLIDER_Ctrl == ((CSliderCtrl *)pScrollBar) ||
		&m_Green_SLIDER_Ctrl == ((CSliderCtrl *)pScrollBar) ||
		&m_Blue_SLIDER_Ctrl == ((CSliderCtrl *)pScrollBar))
	{
		int redGain = m_Red_SLIDER_Ctrl.GetPos();
		int greenGain = m_Green_SLIDER_Ctrl.GetPos();
		int blueGain = m_Blue_SLIDER_Ctrl.GetPos();
		mightex_VideoShow->SetGains(redGain, greenGain, blueGain);
	}
	
	if(&m_XStart_SLIDER_Ctrl == ((CSliderCtrl *)pScrollBar))
	{
		int xStart = m_XStart_SLIDER_Ctrl.GetPos();
		int yStart = m_YStart_SLIDER_Ctrl.GetPos();
		mightex_VideoShow->SetXYStart(xStart, yStart);
	}

	if(&m_YStart_SLIDER_Ctrl == ((CSliderCtrl *)pScrollBar))
	{
		int xStart = m_XStart_SLIDER_Ctrl.GetPos();
		int yStart = m_YStart_SLIDER_Ctrl.GetPos();
		mightex_VideoShow->SetXYStart(xStart, yStart);
	}
	
	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CMightexAppDlg::OnCompressorCHK() 
{//Enalbing or Disalbing Compressor_COMBO
	m_Compressor_CHK = !m_Compressor_CHK;
	m_Compressor_COMBO_Ctrl.EnableWindow(m_Compressor_CHK);
}

void CMightexAppDlg::OnSetFrameRateBtn() 
{//SetFrameRate
	UpdateData();
	double frameRate = atof((const char *)m_FrameRate_Edit);
	mightex_VideoShow->SetStreamFrameRate(10000000 / frameRate);
	
}

void CMightexAppDlg::OnWorkModeRADIO() 
{//SetCameraWorkMode
	if(IsDlgButtonChecked(IDC_WorkMode_RADIO1))
		mightex_VideoShow->SetCameraWorkMode(0);
}

void CMightexAppDlg::OnWorkModeRADIO2()
{//SetCameraWorkMode
	if(IsDlgButtonChecked(IDC_WorkMode_RADIO2))
		mightex_VideoShow->SetCameraWorkMode(1);	
}

void CMightexAppDlg::OnPropertyPageBtn() 
{//OpenPropertyPages
	mightex_VideoShow->OpenPropertyPages(m_hWnd);
}

LRESULT CMightexAppDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{//WindowProc
	if(message == WM_ACTIVATE) 
		if(LOWORD(wParam) == WA_ACTIVE)
			OnDlgActive();

	return CDialog::WindowProc(message, wParam, lParam);
}

void CMightexAppDlg::OnDlgActive()
{//OnDlgActive
	CCameraControl cameraCtrl;
	mightex_VideoShow->GetCameraControl(cameraCtrl);

	if(cameraCtrl.workMode)
		CheckRadioButton(IDC_WorkMode_RADIO1, IDC_WorkMode_RADIO2, IDC_WorkMode_RADIO2);
	else
		CheckRadioButton(IDC_WorkMode_RADIO1, IDC_WorkMode_RADIO2, IDC_WorkMode_RADIO1);
	
	//CheckRadioButton(IDC_Resolution_RADIO1, IDC_Resolution_RADIO2, IDC_Resolution_RADIO2);
	SetDlgItemInt(IDC_Width_Edit, cameraCtrl.width, FALSE);
	SetDlgItemInt(IDC_Height_Edit, cameraCtrl.height, FALSE);
	CheckDlgButton(IDC_Decimation_CHK, cameraCtrl.bin);
	
	char stateMsg[16];
	sprintf(stateMsg, "%dx%d", cameraCtrl.width, cameraCtrl.height);
	SetDlgItemText(IDC_Resolution_STATIC, stateMsg);
	
	int i = m_Exposure_COMBO_Ctrl.GetCurSel();
	if(cameraCtrl.exposureTime >= MAX_EXPOSURETIME[i] * 20)
	{
		if(cameraCtrl.exposureTime >= MAX_EXPOSURETIME[2] * 20)
			i = 3;
		else if(cameraCtrl.exposureTime >= MAX_EXPOSURETIME[1] * 20)
			i = 2;
		else
			i = 1;
		m_Exposure_COMBO_Ctrl.SetCurSel(i);
	}	
	m_Exposure_SLIDER_Ctrl.SetPos(100 * cameraCtrl.exposureTime * 50 / (MAX_EXPOSURETIME[i] * 1000)); //20 = 1000 / 50
	float f_frameTime = cameraCtrl.exposureTime * 50 / 1000.000;
	char tempstr[32];
	sprintf(tempstr, "Exposure Time: ( %gms )", f_frameTime); //20 = 1000 / 50
	SetDlgItemText(IDC_ExposureTime_STATIC, CString( tempstr ) );

	if(s_vidFrameSize[cameraCtrl.MAX_RESOLUTION].width - cameraCtrl.width > 0)
	{
		m_XStart_SLIDER_Ctrl.SetRange(0, s_vidFrameSize[cameraCtrl.MAX_RESOLUTION].width - cameraCtrl.width);
		m_XStart_SLIDER_Ctrl.SetPos(cameraCtrl.xStart);
		m_XStart_SLIDER_Ctrl.EnableWindow(TRUE);
	}
	else
	{
		m_XStart_SLIDER_Ctrl.ClearTics();
		m_XStart_SLIDER_Ctrl.SetPos(0);
		m_XStart_SLIDER_Ctrl.EnableWindow(FALSE);
	}
	
	if(s_vidFrameSize[cameraCtrl.MAX_RESOLUTION].height - cameraCtrl.height > 0)
	{
		m_YStart_SLIDER_Ctrl.SetRange(0, s_vidFrameSize[cameraCtrl.MAX_RESOLUTION].height - cameraCtrl.height);		
		m_YStart_SLIDER_Ctrl.SetPos(cameraCtrl.yStart);
		m_YStart_SLIDER_Ctrl.EnableWindow(TRUE);
	}
	else
	{
		m_YStart_SLIDER_Ctrl.ClearTics();
		m_YStart_SLIDER_Ctrl.SetPos(0);
		m_YStart_SLIDER_Ctrl.EnableWindow(FALSE);
	}
	
	m_Green_SLIDER_Ctrl.SetPos(cameraCtrl.greenGain);
	m_Red_SLIDER_Ctrl.SetPos(cameraCtrl.redGain);
	m_Blue_SLIDER_Ctrl.SetPos(cameraCtrl.blueGain);
	
	float f_FrameRate = 10000000.00 / cameraCtrl.streamFrameRate;
	sprintf(tempstr, "%.2f\0", f_FrameRate);
	SetDlgItemText(IDC_FrameRate_Edit, tempstr);

	mightex_VideoShow->SetWindowCaption();
}

void CMightexAppDlg::OnSelectFilePathBtn() 
{//SelectFilePath
	char szPath[256];
	char szTitle[] = "File Path";
	char szDlgTitle[] = "select dir";
	BROWSEINFO bi;   
	LPITEMIDLIST lpi;   
    
	bi.hwndOwner = m_hWnd;   
	bi.pidlRoot = NULL;   
	bi.pszDisplayName = NULL;   
	bi.lpszTitle = szTitle;   
	bi.ulFlags = BIF_RETURNONLYFSDIRS|BIF_RETURNFSANCESTORS;   
	bi.lpfn = NULL;   
	bi.lParam = (LPARAM)szDlgTitle;   
	bi.iImage = 0;   
	lpi = SHBrowseForFolder(&bi);   
	if(lpi   ==   NULL) return;   
    
	LPMALLOC pMalloc;   
	SHGetMalloc(&pMalloc);   
	if(SHGetPathFromIDList(lpi,szPath))
		SetDlgItemText(IDC_FilePath_Edit, strcat(szPath, "\\"));
	pMalloc->Free(lpi);   
	pMalloc->Release();   
}

void CMightexAppDlg::OnTimer(UINT nIDEvent) 
{
	mightex_VideoShow->SetWindowCaption();	
	CDialog::OnTimer(nIDEvent);
}

void CMightexAppDlg::OnClose() 
{
	KillTimer(1);
	CDialog::OnClose();
}

/////////////////////////////////////////////////////////////////////////////
