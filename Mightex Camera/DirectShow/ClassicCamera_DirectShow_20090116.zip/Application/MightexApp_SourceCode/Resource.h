//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MightexApp.rc
//
#define IDD_MIGHTEXAPP_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP                      133
#define IDC_ConnectBtn                  1000
#define IDC_SnapshotBtn                 1002
#define IDC_ConnectBtn2                 1003
#define IDC_FileName_Edit               1004
#define IDC_Resolution_RADIO1           1005
#define IDC_SnapshotNum_Edit            1006
#define IDC_Resolution_RADIO2           1007
#define IDC_Resolution_COMBO            1008
#define IDC_Width_Edit                  1009
#define IDC_Height_Edit                 1010
#define IDC_SetResolutionBtn            1011
#define IDC_Exposure_COMBO              1012
#define IDC_Exposure_SLIDER             1013
#define IDC_FilePath_Edit               1014
#define IDC_JPEGFile_CHK                1015
#define IDC_Append_DateTime_CHK         1016
#define IDC_ConnectBtn3                 1017
#define IDC_ConnectBtn4                 1018
#define IDC_XStart_SLIDER               1019
#define IDC_YStart_SLIDER               1020
#define IDC_Red_SLIDER                  1021
#define IDC_Green_SLIDER                1022
#define IDC_Blue_SLIDER                 1023
#define IDC_Device_COMBO                1024
#define IDC_FrameRate_Edit              1025
#define IDC_SetFrameRateBtn             1026
#define IDC_PropertyPageBtn             1027
#define IDC_ExposureTime_STATIC         1028
#define IDC_Compressor_COMBO            1029
#define IDC_Compressor_CHK              1030
#define IDC_Resolution_STATIC           1031
#define IDC_State_STATIC                1032
#define IDC_Snapshot_STATIC             1033
#define IDC_Decimation_CHK              1034
#define IDC_Red_STATIC                  1035
#define IDC_Blue_STATIC                 1036
#define IDC_Green_STATIC                1037
#define IDC_WorkMode_RADIO1             1038
#define IDC_WorkMode_RADIO2             1039
#define IDC_SelectFilePathBtn           1040
#define IDC_DeviceName_STATIC           1041

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
